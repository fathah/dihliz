  <!-- End Slider -->
  <!-- Start service  -->
  <section id="mu-service">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-service-area">
            <!-- Start single service -->
            <div class="mu-service-single">
              <span class="fa fa-book"></span>
              <h3>HSS SCIENCE</h3>
              <p>
              With Medical, Engineering Coaching from domain experts
              </p>
            </div>

            <!-- Start single service -->
            <!-- Start single service -->
            <div class="mu-service-single" >
              <span class="fa fa-users"></span>
              <h3>HSS COMMERCE</h3>
              <p>With CA, CS, CMA Foundation from professionals</p>
         </div>

            <!-- Start single service -->
            <!-- Start single service -->
            <div class="mu-service-single" >
              <span class="fa fa-table"></span>
              <h3>HIGH SCHOOL</h3>
              <p>With Life Skills Training and Competitive Exam Coaching</p>
            </div>
            <!-- Start single service -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End service  -->