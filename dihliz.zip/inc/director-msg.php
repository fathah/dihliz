  <!-- Start our teacher -->

  
  <section id="mu-our-teacher">
    <div class="container">
      <div class="row">
      <div class="mu-title">
              <h2>Director's Message</h2>
            </div>
<div  class="col-md-3">
<center><img src="assets/img/teachers/hkm-ustd.png"  alt=""></center>
</div>
        <div class="col-md-6">
          <div class="mu-our-teacher-area">
            <!-- begain title -->
            
            <!-- end title -->
           
          
                   
          

  Dihliz World School prepares you to achieve your goals in the rapidly and constantly changing environment of global education. Structured in a serene garden, Dihliz delivers the competitive advantages and global experience of commerce, science and high school. The dire need of the hour to mould ethically inspired professionals and leaders incorporated the ideas of Islamic value system in substantially  met and fulfilled at this garden of innovative mission and practical wisdom.
<br> <br>
<b>Dr. MAH Azhari</b> <br>
<i>Director, Dihliz</i>
        
            <!-- End our teacher content -->           
        </div>
      </div>


    </div>
  </section>
  <!-- End our teacher -->