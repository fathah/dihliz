 <!-- Start Slider -->
 <section id="mu-slider">
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src="assets/img/slider/1.jpg" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>Making Better Humans</h4>
        <span></span>
        <h2>Welcome To Dihliz</h2>
<p>A school for excellence under Markaz Garden, prioritizes quality, values and ethos
</p>        <a href="#" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src="assets/img/slider/2.jpg" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
      <h4>Making Better Humans</h4>
        <span></span>
        <h2>Cutting-Edge Schooling</h2>
<p>A Global Gateway to the Cutting – Edge Schooling with a vision that called for creating, molding and developing ethically sound professionals in the fields concerned. </p>        
<a href="#" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src="assets/img/slider/3.jpg" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
      <h4>Making Better Humans</h4>
        <span></span>
        <h2>Grow Globally at Markaz Garden</h2>
<p>Dihliz opens the world of opportunities to expand the future connections.</p>
        <a href="#" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->    
  </section>