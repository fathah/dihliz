<!DOCTYPE html>
<html lang="en">
<?php include 'inc/head.php'; ?>
  <body> 
  <?php include 'inc/nav.php';
  
  ?>
  
  <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>      
    </a>
  <!-- END SCROLL TOP BUTTON -->



 <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-page-breadcrumb-area">
           <h2>Dihliz Directors Board</h2>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- End breadcrumb -->
 <section id="mu-course-content">
   <div class="container"  style="background:#fff; padding:20px;">
   <div class="mu-blog-description">
  
<p>
<h4>DR. MAH AZHARI (DIRECTOR)</h4>
<h4>DR. ABDUSSALAM </h4>
<h4>DR. UMARUL FARUQ SAQAFI</h4>
<h4>MR. NOUFAL HASSAN NURANI</h4>


</p>


</div>
     </div>
   </div>
 </section>




 <?php include'inc/footer.php'; ?>
 
  

  
  </body>
</html>