<!DOCTYPE html>
<html lang="en">
<?php include 'inc/head.php'; ?>
  <body> 
  <?php include 'inc/nav.php';
  
  ?>
  
  <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>      
    </a>
  <!-- END SCROLL TOP BUTTON -->



 <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-page-breadcrumb-area">
           <h2>About Dihliz</h2>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- End breadcrumb -->
 <section id="mu-course-content">
   <div class="container"  style="background:#fff; padding:20px;">
   <div class="mu-blog-description">
  
<p id="about">
Dihilz, a  phrase meaning threshold in Persian, continues the journey that GSV started more than one decade before.   Dihliz World School, runs under Markaz Garden, Calicut, plans its residential school system with a new advanced approach and outstanding curriculum to expand its global connections. It explores excellence in all the academic and non-academic areas to mould the students as 'ideal' in the areas concerned.
</p>
<br>
</div>
     </div>
   </div>
 </section>




 <?php include'inc/footer.php'; ?>
 
  

  
  </body>
</html>